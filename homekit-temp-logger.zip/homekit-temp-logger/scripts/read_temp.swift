#!/usr/bin/env swift
// read_temp.swift
// Reads temperature from the first HomeKit temperature sensor found.
// Outputs a single line: { "celsius": 21.5, "name": "Living Room" }
// Exits with code 1 if no sensor is found.

import HomeKit
import Foundation

class TempReader: NSObject, HMHomeManagerDelegate {
    let manager = HMHomeManager()
    var didFinish = false

    override init() {
        super.init()
        manager.delegate = self
        // Keep runloop alive until we finish
        while !didFinish {
            RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
        }
    }

    func homeManagerDidUpdateHomes(_ manager: HMHomeManager) {
        for home in manager.homes {
            for accessory in home.accessories {
                for service in accessory.services {
                    for characteristic in service.characteristics {
                        // HMCharacteristicTypeCurrentTemperature
                        if characteristic.characteristicType == "00000011-0000-1000-8000-0026BB765291" {
                            characteristic.readValue { error in
                                if let value = characteristic.value as? Double {
                                    let output: [String: Any] = [
                                        "celsius": value,
                                        "fahrenheit": value * 9/5 + 32,
                                        "name": accessory.name
                                    ]
                                    if let json = try? JSONSerialization.data(withJSONObject: output),
                                       let str = String(data: json, encoding: .utf8) {
                                        print(str)
                                    }
                                    self.didFinish = true
                                } else {
                                    fputs("Error reading value: \(error?.localizedDescription ?? "unknown")\n", stderr)
                                    self.didFinish = true
                                    exit(1)
                                }
                            }
                            return
                        }
                    }
                }
            }
        }
        fputs("No temperature sensor found in HomeKit.\n", stderr)
        exit(1)
    }
}

_ = TempReader()
